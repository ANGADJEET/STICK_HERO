package com.example.project;

public interface Rectangle {
    double getWidth();
    double getHeight();
}
