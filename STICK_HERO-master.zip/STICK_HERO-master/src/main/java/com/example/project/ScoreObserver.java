package com.example.project;

public interface ScoreObserver {
    void updateScore(int newScore);
}
