package com.example.project;

public interface Collider {
    boolean checkCollision(Collider other);
}
