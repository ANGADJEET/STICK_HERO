package com.example.project;

public class GamePlayMenu {
    public void displayMenu() {
        // Display in-game menu options
    }

    public void saveAndExit() {
        // Save the game and exit to the main menu
    }

    public void displayScore() {
        // Display the current score
    }

    // Other in-game menu-related methods
}
